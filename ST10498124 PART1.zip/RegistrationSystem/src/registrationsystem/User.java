/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registrationsystem;

/**
 *
 * @author Student
 */
public class User {
    
    private String storedUsername;
    private String storedPassword;
    private String storedPhone;
    private String firstName;
    private String lastName;
    
    public User() {}
    
    public User(String username, String password, String phone, String firstName, String lastName) {
        this.storedUsername = username;
        this.storedPassword = password;
        this.storedPhone = phone;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Getters and Setters
    public String getStoredUsername() { return storedUsername; }
    public void setStoredUsername(String storedUsername) { this.storedUsername = storedUsername; }
    
    public String getStoredPassword() { return storedPassword; }
    public void setStoredPassword(String storedPassword) { this.storedPassword = storedPassword; }
    
    public String getStoredPhone() { return storedPhone; }
    public void setStoredPhone(String storedPhone) { this.storedPhone = storedPhone; }
    
    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    
    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
}
